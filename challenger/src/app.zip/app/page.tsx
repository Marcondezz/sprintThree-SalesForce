import "./css/style.css"
import Pagina_inicial from "./Pagina_Inicial/page"


const Home = () =>{
    return(
      <>
      <Pagina_inicial />
      </>
    )
  }
  export default Home;