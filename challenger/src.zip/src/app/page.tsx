import "./css/style.css"
import PAGINA_INICIAL from "./Pagina_Inicial/page"


const Home = () =>{
    return(
      <>
      </>
    )
  }
  export default Home;